<?php
/**
 * Plugin Name:       Tag Manager for SureCart
 * Description:       Map SureCart price IDs to FluentCRM tags and assign tags on purchase.
 * Tested up to:      6.8.1
 * Requires at least: 6.5
 * Requires PHP:      8.0
 * Version:           1.0.6
 * Author:            Reallyusefulplugins.com
 * Author URI:        https://reallyusefulplugins.com
 * License:           GPL2
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       rup-crm-tag-mapper
 * Website:           https://reallyusefulplugins.com
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'RUP_CRM_TM_MANAGER_VERSION', '1.0.6' );

// Option keys
define( 'RUP_CRM_TM_OPTION_ENABLED',  'rup_crm_tm_enabled' );
define( 'RUP_CRM_TM_OPTION_MAPPINGS', 'rup_crm_tm_mappings' );

/* --------------------------------------------------
   DEBUGGING HELPER FUNCTION
   define( 'rup_crm_tm_debug', true );
-------------------------------------------------- */
function rup_crm_tm_debuglog( $message ) {
    if ( defined( 'rup_crm_tm_debug' ) && rup_crm_tm_debug === true ) {
        error_log( $message );
    }
}

/**
 * Register settings: enable checkbox and mapping repeater
 */
add_action( 'admin_init', function() {
    register_setting( 'rup_crm_tm_group', RUP_CRM_TM_OPTION_ENABLED, [
        'type'              => 'string',
        'sanitize_callback' => function( $v ) {
            return $v === '1' ? '1' : '0';
        },
        'default'           => '0',
    ] );

    // Store mappings as JSON with multiple tags
    register_setting( 'rup_crm_tm_group', RUP_CRM_TM_OPTION_MAPPINGS, [
        'type'              => 'string',
        'sanitize_callback' => function( $v ) {
            // 1) If loading existing JSON, leave untouched
            if ( is_string( $v ) && null !== json_decode( $v, true ) ) {
                return $v;
            }
            // 2) If sanitizing form POST (array), encode it
            if ( is_array( $v ) ) {
                return wp_json_encode( array_map( function( $map ) {
                    return [
                        'price_id' => sanitize_text_field( $map['price_id'] ?? '' ),
                        'tags'     => array_values( array_map( 'sanitize_text_field', (array) ( $map['tags'] ?? [] ) ) ),
                        'enabled'  => ( isset( $map['enabled'] ) && $map['enabled'] === '1' ) ? '1' : '0',
                    ];
                }, $v ) );
            }
            // 3) Anything else: empty list
            return '[]';
        },
        'default'           => '[]',
    ] );
} );


/**
 * Add settings page under Settings menu
 */
add_action( 'admin_menu', function() {
    add_submenu_page(
        'sc-onboarding-checklist',
        'CRM Tag Mapper',
        'CRM Tag Mapper',
        'manage_sc_shop_settings',
        'rup-crm-tag-mapper',
        'rup_crm_tm_render_admin_page'
    );
}, 100 );

/**
 * Render admin settings page (with per‐row delete buttons).
 */
function rup_crm_tm_render_admin_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    // Handle deletion requests
    if ( isset( $_GET['delete_mapping'] ) && isset( $_GET['_wpnonce'] ) ) {
        $delete_index = absint( $_GET['delete_mapping'] );
        $nonce_action = 'rup_crm_tm_delete_' . $delete_index;
        if ( wp_verify_nonce( $_GET['_wpnonce'], $nonce_action ) ) {
            $json     = get_option( RUP_CRM_TM_OPTION_MAPPINGS, '[]' );
            $mappings = json_decode( $json, true );
            if ( is_array( $mappings ) && isset( $mappings[ $delete_index ] ) ) {
                unset( $mappings[ $delete_index ] );
                $mappings = array_values( $mappings );
                update_option( RUP_CRM_TM_OPTION_MAPPINGS, wp_json_encode( $mappings ) );
            }
        }
        // Redirect back to base URL (remove query args)
        $base_url = remove_query_arg( [ 'delete_mapping', '_wpnonce' ] );
        wp_safe_redirect( $base_url );
        exit;
    }

    // Load settings
    $enabled  = get_option( RUP_CRM_TM_OPTION_ENABLED, '0' );
    $json     = get_option( RUP_CRM_TM_OPTION_MAPPINGS, '[]' );
    $mappings = json_decode( $json, true );
    if ( ! is_array( $mappings ) ) {
        $mappings = [];
    }
    if ( empty( $mappings ) ) {
        $mappings = [
            [
                'price_id' => '',
                'tags'     => [],
                'enabled'  => '1',
            ]
        ];
    }

    // Fetch FluentCRM tags
    $tags = [];
    if ( function_exists( 'FluentCrmApi' ) ) {
        try {
            $tags = FluentCrmApi( 'tags' )->all();
        } catch ( Exception $e ) {
            $tags = [];
        }
    }
    ?>
    <div class="wrap">
        <h1>CRM Tag Mapper</h1>
        <form method="post" action="options.php">
            <?php settings_fields( 'rup_crm_tm_group' ); ?>

            <table class="form-table">
                <tr>
                    <th scope="row">Enable Tag Mapping</th>
                    <td>
                        <input type="checkbox"
                               name="<?php echo esc_attr( RUP_CRM_TM_OPTION_ENABLED ); ?>"
                               value="1"
                            <?php checked( $enabled, '1' ); ?> />
                    </td>
                </tr>
                <tr>
                    <th scope="row">Price ID → Tags Mappings</th>
                    <td id="rup-crm-tm-mappings">
                        <?php foreach ( $mappings as $index => $map ) : ?>
                            <div class="rup-mapping-row" style="margin-bottom:10px;">
                                <!-- Price ID Field -->
                                <label>
                                    Price ID:
                                    <input type="text"
                                           name="<?php echo esc_attr( RUP_CRM_TM_OPTION_MAPPINGS ); ?>[<?php echo $index; ?>][price_id]"
                                           value="<?php echo esc_attr( $map['price_id'] ); ?>" />
                                </label>

                                <!-- Tags Multi-Select -->
                                <label style="margin-left:20px;">
                                    Tags:
                                    <select name="<?php echo esc_attr( RUP_CRM_TM_OPTION_MAPPINGS ); ?>[<?php echo $index; ?>][tags][]"
                                            multiple
                                            style="min-width:200px; height:6em;">
                                        <?php foreach ( $tags as $tagObj ) : ?>
                                            <option value="<?php echo esc_attr( $tagObj->slug ); ?>"
                                                <?php echo in_array( $tagObj->slug, (array) $map['tags'], true ) ? 'selected' : ''; ?>>
                                                <?php echo esc_html( $tagObj->title ); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </label>

                                <!-- Enabled Checkbox -->
                                <label style="margin-left:20px;">
                                    <input type="checkbox"
                                           name="<?php echo esc_attr( RUP_CRM_TM_OPTION_MAPPINGS ); ?>[<?php echo $index; ?>][enabled]"
                                           value="1"
                                        <?php checked( $map['enabled'], '1' ); ?> />
                                    Enabled
                                </label>

                                <!-- Delete Button -->
                                <?php
                                $delete_nonce = wp_create_nonce( 'rup_crm_tm_delete_' . $index );
                                $delete_url   = add_query_arg( [
                                    'page'           => 'rup-crm-tag-mapper',
                                    'delete_mapping' => $index,
                                    '_wpnonce'       => $delete_nonce,
                                ], admin_url( 'admin.php' ) );
                                ?>
                                <a href="<?php echo esc_url( $delete_url ); ?>"
                                   class="button-link delete-mapping"
                                   onclick="return confirm('Are you sure you want to delete this mapping?');"
                                   style="color: #a00; margin-left:8px;">
                                    Delete
                                </a>
                            </div>
                        <?php endforeach; ?>

                        <!-- Add Mapping Button -->
                        <p>
                            <button type="button" class="button" id="rup-crm-tm-add">
                                Add Mapping
                            </button>
                        </p>
                    </td>
                </tr>
            </table>

            <?php submit_button(); ?>
        </form>
    </div>

    <!-- JavaScript to clone a new mapping row -->
    <script>
    (function(){
        var container = document.getElementById('rup-crm-tm-mappings');
        var btn       = document.getElementById('rup-crm-tm-add');

        btn.addEventListener('click', function(){
            var rows      = container.querySelectorAll('.rup-mapping-row');
            if (!rows.length) return;
            var last      = rows[rows.length - 1];
            var clone     = last.cloneNode(true);
            var newIndex  = rows.length;

            clone.querySelectorAll('input, select, a.delete-mapping').forEach(function(el){
                // Update name attributes
                if (el.name) {
                    var name = el.getAttribute('name')
                                .replace(/\[\d+\]/, '[' + newIndex + ']');
                    el.setAttribute('name', name);
                }
                // Clear text inputs & reset checkboxes
                if (el.tagName === 'INPUT') {
                    if (el.type === 'text')     el.value   = '';
                    if (el.type === 'checkbox') el.checked = true;
                }
                // De-select all options in multi-select
                if (el.tagName === 'SELECT') {
                    Array.from(el.options).forEach(function(opt){
                        opt.selected = false;
                    });
                }
                // Remove old delete-link so it regenerates on save
                if (el.classList.contains('delete-mapping')) {
                    el.remove();
                }
            });

            container.insertBefore(clone, btn.parentNode);
        });
    })();
    </script>
    <?php
}


/**
 * Handle SureCart checkout: map price IDs to tags and update FluentCRM
 */
add_action( 'surecart/checkout_confirmed', function( $checkout, $request ) {
    if ( get_option( RUP_CRM_TM_OPTION_ENABLED ) !== '1' ) {
        return;
    }

    $json     = get_option( RUP_CRM_TM_OPTION_MAPPINGS, '[]' );
    $mappings = json_decode( $json, true );

    if ( empty( $mappings ) || ! function_exists( 'FluentCrmApi' ) ) {
        return;
    }

    $email      = $checkout->email ?? '';
    $first_name = $checkout->first_name ?? '';
    $last_name  = $checkout->last_name ?? '';
    $items      = is_array( $checkout->line_items->data ) ? $checkout->line_items->data : [];

    $tags_to_apply = [];

    foreach ( $items as $item ) {
        foreach ( $mappings as $map ) {
            if ( $map['enabled'] === '1' && $map['price_id'] === $item->price_id && ! empty( $map['tags'] ) ) {
                foreach ( (array) $map['tags'] as $slug ) {
                    if ( $slug ) {
                        $tags_to_apply[] = $slug;
                        rup_crm_tm_debuglog( "Matched price {$item->price_id}, applying tag {$slug}" );
                    }
                }
            }
        }
    }

    if ( empty( $tags_to_apply ) || ! $email ) {
        return;
    }

    $data = [
        'email'      => $email,
        'first_name' => $first_name,
        'last_name'  => $last_name,
        'status'     => 'subscribed',
        'tags'       => array_values( array_unique( $tags_to_apply ) ),
    ];

    try {
        $subscriber = FluentCrmApi( 'contacts' )->createOrUpdate( $data );
        if ( $subscriber && $subscriber->status === 'pending' ) {
            $subscriber->sendDoubleOptinEmail();
        }
    } catch ( Exception $e ) {
        rup_crm_tm_debuglog( 'FluentCRM error: ' . $e->getMessage() );
    }
}, 10, 2 );


/**
 * Plugin updater
 */
add_action( 'plugins_loaded', function() {
    $updater_config = [
        'plugin_file' => plugin_basename( __FILE__ ),
        'slug'        => 'rup-crm-tag-mapper',
        'name'        => 'Tag Manager for SureCart',
        'version'     => RUP_CRM_TM_MANAGER_VERSION,
        'key'         => 'CeW5jUv66xCMVZd83QTema',
        'server'      => 'https://updater.reallyusefulplugins.com/u/',
    ];

    require_once __DIR__ . '/inc/updater.php';
    new \UUPD\V1\UUPD_Updater_V1( $updater_config );
} );
